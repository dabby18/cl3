package com.example.shubh.mycalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView exp;
    Button del;
    String currentExp;
    String myExp;
    String save;
    int state;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        currentExp = "";
        myExp = "";
        state = 0;
        exp = (TextView) findViewById(R.id.exp);
        del = (Button) findViewById(R.id.mydel);

        exp.setMovementMethod(new ScrollingMovementMethod());
    }

    public void set(View v){
        String temp = v.getTag().toString();
        String myTemp = temp;
        if(state == 1){
            currentExp = "";
            myExp = "";
            state = 0;
            del.setText("DEL");
        }

        switch(temp){
            case "+":
                if(currentExp.equals("")) {
                    temp = save + temp;
                    myTemp = save + " + ";
                }
                else
                    myTemp = " + ";
                break;
            case "-":
                if(currentExp.equals("")) {
                    temp = save + temp;
                    myTemp = save + " - ";
                }
                else
                    myTemp = " - ";
                break;
            case "*":
                if(currentExp.equals("")) {
                    temp = save + temp;
                    myTemp = save + " * ";
                }
                else
                    myTemp = " * ";
                break;
            case "/":
                if(currentExp.equals("")) {
                    temp = save + temp;
                    myTemp = save + " / ";
                }
                else
                    myTemp = " / ";
                break;
            case "sin":
                temp = "sin(";
                myTemp = temp;
                break;
            case "cos":
                temp = "cos(";
                myTemp = temp;
                break;
            case "tan":
                temp = "tan(";
                myTemp = temp;
                break;
            case "DEL":
                temp = "";
                myTemp = temp;
                if(currentExp.length()>0) {
                    currentExp = currentExp.substring(0, currentExp.length() - 1);
                    if(myExp.endsWith(" "))
                        myExp = myExp.substring(0, myExp.length() - 3);
                    else
                        myExp = myExp.substring(0, myExp.length() - 1);
                }
                break;
            case "PI":
                temp = "\u03C0";
                myTemp = String.valueOf(Math.PI);
                break;
            case "ac":
                temp = "";
                myTemp = temp;
                currentExp = "";
                myExp = "";
                break;
            case "recall":
                temp = save;
                myTemp = temp;
                break;
            case "=":
                temp = "";
                myTemp = temp;
                currentExp += "\n";
                del.setText("CLR");
                state = 1;

                temp = calculateExp(myExp);
                save = temp;
                break;
        }

        currentExp += temp;
        myExp += myTemp;
        exp.setText(currentExp);
    }

    private String calculateExp(String myExp){
        String strArray[] = myExp.split(" ");

        for(int i = 0; i < strArray.length; i++){
            if(strArray[i].contains("sin")){
                String trig[] = strArray[i].split("[\\(||\\)]");
                double result = Math.sin(Double.parseDouble(trig[1]));
                strArray[i] = result+"";
            }
            else if(strArray[i].contains("cos")){
                String trig[] = strArray[i].split("[\\(||\\)]");
                double result = Math.cos(Double.parseDouble(trig[1]));
                strArray[i] = result+"";
            }
            else if(strArray[i].contains("tan")){
                String trig[] = strArray[i].split("[\\(||\\)]");
                double result = Math.tan(Double.parseDouble(trig[1]));
                strArray[i] = result+"";
            }
        }

        for(int i = 1; i < strArray.length; i+=2){
            if(strArray[i].equals("+")){
                float num1 = Float.parseFloat(strArray[i-1]);
                float num2 = Float.parseFloat(strArray[i+1]);
                float tmp = num1 + num2;
                strArray[i+1] = String.valueOf(tmp);
            }
            else if(strArray[i].equals("-")){
                float num1 = Float.parseFloat(strArray[i-1]);
                float num2 = Float.parseFloat(strArray[i+1]);
                float tmp = num1 - num2;
                strArray[i+1] = String.valueOf(tmp);
            }
            else if(strArray[i].equals("*")){
                float num1 = Float.parseFloat(strArray[i-1]);
                float num2 = Float.parseFloat(strArray[i+1]);
                float tmp = num1 * num2;
                strArray[i+1] = String.valueOf(tmp);
            }
            else if(strArray[i].equals("/")){
                float num1 = Float.parseFloat(strArray[i-1]);
                float num2 = Float.parseFloat(strArray[i+1]);
                float tmp = num1 / num2;
                strArray[i+1] = String.valueOf(tmp);
            }
        }

        if(strArray[strArray.length-1].endsWith(".0"))
            strArray[strArray.length-1] = strArray[strArray.length-1].substring(0, strArray[strArray.length-1].length()-2);
        return strArray[strArray.length-1];
    }
}
